<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Monitoring - <?php echo e($monitoring->title); ?></title>
    <style>
        @import  url('https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');
        /* @font-face {
            font-family: 'Montserrat';
            font-style: normal;
            font-weight: normal;
            src: url(http://themes.googleusercontent.com/static/fonts/sourcesanspro/v7/ODelI1aHBYDBqgeIAH2zlNzbP97U9sKh0jjxbPbfOKg.ttf) format('truetype');
        } */
        @page  {
            margin: 0px;
        }
        body {
            margin: 0px;
        }
        .header {
            padding: 1.2rem;
            padding-bottom: 0 !important;
            position: relative;
        }
        .description-content p {
            margin: 0 !important;
        }
        .body {
            padding: 1.2rem;
            padding-top: 0.8rem !important;
            position: relative;
        }
        * {
            font-family: 'Montserrat', Arial, sans-serif;
            word-break: break-all !important;
        }
        span {
            word-break: break-all !important;
        }
        a {
            word-break: break-all !important;
            color: #2D2A70;
            text-decoration: none;
        }
        .value-input {
            padding: .5rem;
            background-color: rgb(245, 245, 245);
            border-radius: .25rem;
            word-break: break-all !important;
            border: 2px solid rgb(224, 224, 224);
            margin-bottom: 12px;
        }

    </style>
</head>
<body>
    <div class="header">
        <img src="data:image/png;base64,<?php echo e($logoDishub); ?>" width="50px" alt="Logo Dishub">
        <img src="data:image/png;base64,<?php echo e($logoBTP); ?>" width="50px" style="margin: 0px 24px" alt="Logo BTP Jabar">
        <img src="data:image/png;base64,<?php echo e($logoApp); ?>" style="position: absolute; right: 0; top: 0; margin: .95rem" width="64px" alt="Logo App">
        <div style="display: block">
            <p style="font-size: 1.2rem; margin-bottom: 1px; font-weight: bold">BALAI PERKERETAAPIAN - JAWABARAT</p>
            <p style="font-size: .9rem; margin: 0 0 20px 0;">Jl Raya Gedebage No 68 Bandung, Jawabarat</p>
            <div style="height: 4px; width: 100%; background-color: #BBB8FB"></div>
        </div>
    </div>
    <div class="body">
        <div style="text-align: center">
            <p style="font-size: 1.2rem; margin-bottom: 1px !important; font-weight: bold">LAPORAN MONITORING</p>
            <p style="font-size: .9rem; margin: 0 0 20px 0;">Aplikasi Inovatif SIMPKA</p>
        </div>
        <div style="text-align: left; padding: .5rem">
            <table style="width: 100%">
                <tr>
                    <td><b>Judul Monitoring</b></td>
                    <th>:</th>
                    <td><?php echo e($monitoring->title); ?></td>
                </tr>
                <tr>
                    <td><b>Tim Monitoring</b></td>
                    <th>:</th>
                    <td><?php echo e($monitoring->team->name); ?></td>
                </tr>
                <tr>
                    <td><b>Sujek Monitoring</b></td>
                    <th>:</th>
                    <td><?php echo e($monitoring->employee->name); ?></td>
                </tr>
                <tr>
                    <td><b>Deskripsi</b></td>
                    <th>:</th>
                    <td class="description-content"><?php echo $monitoring->description; ?></td>
                </tr>
            </table>
        </div>
        <?php if(count($inputs['category']) > 0): ?>
            <div style="margin-top: 24px; padding-top: 20px; border-top: 3px solid gainsboro; padding-left: 10px">
                <p style="font-size: 1rem; font-weight: bold; margin: 0 0 0px 0;">Formulir <?php echo e($category->name); ?></p>
                <p style="font-size: .9rem; margin: 6px 0 20px 0;">Formulir berdasarkan kategori</p>
            </div>
            <?php $__currentLoopData = $inputs['category']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ol style="list-style: none">
                    <li style="margin-bottom: 8px"><u><?php echo e($input->label); ?> :</u></li>
                    <li class="value-input">
                        <?php if($input->valueData != null && count($input->valueData) > 0): ?>
                            <?php if($input->type == 'text'): ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                <div class="description-content">
                                    <?php echo $input->valueData[0]->text_value; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                <?php echo e($input->valueData[0]->number_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                <?php if($input->valueData[0]->type_file == 'image'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'excel'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Excel - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'ppt'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Presentation - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'document'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Document - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'pdf'): ?>
                                    <span style="display: inline-block; font-weight: bold">File PDF - </span>
                                <?php endif; ?>
                                <a style="display: inline-block" href="<?php echo e(route('app.value.download', ['id' => $input->valueData[0]->id])); ?>">
                                    <?php echo e($input->valueData[0]->file_value); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                <?php echo e(\Carbon\Carbon::parse($input->valueData[0]->date_value)->format('l, d F Y')); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                <?php echo e($input->valueData[0]->time_value); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($input->type == 'text'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'description'): ?>
                                <div class="description-content">
                                    <?php echo $input->description; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'image'): ?>
                                <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <a style="display: inline-block" href="<?php echo e(route('app.input-image.download', ['id' => $input->id])); ?>">
                                    <?php echo e($input->image); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'media-youtube'): ?>
                                <a href="<?php echo e($input->link); ?>">
                                    <?php echo e($input->link); ?>

                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </li>
                </ol>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(count($inputs['object']) > 0): ?>
            <div style="margin-top: 24px; padding-top: 20px; border-top: 3px solid gainsboro; padding-left: 10px">
                <p style="font-size: 1rem; font-weight: bold; margin: 0 0 0px 0;">Formulir <?php echo e($object->name); ?></p>
                <p style="font-size: .9rem; margin: 6px 0 20px 0;">Formulir berdasarkan objek</p>
            </div>
            <?php $__currentLoopData = $inputs['object']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ol style="list-style: none">
                    <li style="margin-bottom: 8px"><u><?php echo e($input->label); ?> :</u></li>
                    <li class="value-input">
                        <?php if($input->valueData != null && count($input->valueData) > 0): ?>
                            <?php if($input->type == 'text'): ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                <div class="description-content">
                                    <?php echo $input->valueData[0]->text_value; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                <?php echo e($input->valueData[0]->number_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                <?php if($input->valueData[0]->type_file == 'image'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'excel'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Excel - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'ppt'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Presentation - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'document'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Document - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'pdf'): ?>
                                    <span style="display: inline-block; font-weight: bold">File PDF - </span>
                                <?php endif; ?>
                                <a style="display: inline-block" href="<?php echo e(route('app.value.download', ['id' => $input->valueData[0]->id])); ?>">
                                    <?php echo e($input->valueData[0]->file_value); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                <?php echo e(\Carbon\Carbon::parse($input->valueData[0]->date_value)->format('l, d F Y')); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                <?php echo e($input->valueData[0]->time_value); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($input->type == 'text'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'description'): ?>
                                <div class="description-content">
                                    <?php echo $input->description; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'image'): ?>
                                <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <a style="display: inline-block" href="<?php echo e(route('app.input-image.download', ['id' => $input->id])); ?>">
                                    <?php echo e($input->image); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'media-youtube'): ?>
                                <a href="<?php echo e($input->link); ?>">
                                    <?php echo e($input->link); ?>

                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </li>
                </ol>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(count($inputs['monitoring']) > 0): ?>
            <div style="margin-top: 24px; padding-top: 20px; border-top: 3px solid gainsboro; padding-left: 10px">
                <p style="font-size: 1rem; font-weight: bold; margin: 0 0 0px 0;">Formulir <?php echo e($monitoring->title); ?></p>
                <p style="font-size: .9rem; margin: 6px 0 20px 0;">Formulir berdasarkan data monitoring</p>
            </div>
            <?php $__currentLoopData = $inputs['monitoring']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ol style="list-style: none">
                    <li style="margin-bottom: 8px"><u><?php echo e($input->label); ?> :</u></li>
                    <li class="value-input">
                        <?php if($input->valueData != null && count($input->valueData) > 0): ?>
                            <?php if($input->type == 'text'): ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                <div class="description-content">
                                    <?php echo $input->valueData[0]->text_value; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                <?php echo e($input->valueData[0]->number_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($input->valueData[0]->string_value); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                <?php if($input->valueData[0]->type_file == 'image'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'excel'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Excel - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'ppt'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Presentation - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'document'): ?>
                                    <span style="display: inline-block; font-weight: bold">File Document - </span>
                                <?php endif; ?>
                                <?php if($input->valueData[0]->type_file == 'pdf'): ?>
                                    <span style="display: inline-block; font-weight: bold">File PDF - </span>
                                <?php endif; ?>
                                <a style="display: inline-block" href="<?php echo e(route('app.value.download', ['id' => $input->valueData[0]->id])); ?>">
                                    <?php echo e($input->valueData[0]->file_value); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                <?php echo e(\Carbon\Carbon::parse($input->valueData[0]->date_value)->format('l, d F Y')); ?>

                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                <?php echo e($input->valueData[0]->time_value); ?>

                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($input->type == 'text'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'textarea'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'number'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'date'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'file'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'time'): ?>
                                Tidak ada data
                            <?php endif; ?>
                            <?php if($input->type == 'dropdown'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'checkbox'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'radio'): ?>
                                <?php $__currentLoopData = $input->option; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option->optionValue != null && count($option->optionValue) > 0): ?>
                                        <?php $__currentLoopData = $option->optionValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span><?php echo e($value->value); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($input->type == 'description'): ?>
                                <div class="description-content">
                                    <?php echo $input->description; ?>

                                </div>
                            <?php endif; ?>
                            <?php if($input->type == 'image'): ?>
                                <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                                <a style="display: inline-block" href="<?php echo e(route('app.input-image.download', ['id' => $input->id])); ?>">
                                    <?php echo e($input->image); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($input->type == 'media-youtube'): ?>
                                <a href="<?php echo e($input->link); ?>">
                                    <?php echo e($input->link); ?>

                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </li>
                </ol>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(count($images) > 0): ?>
            <div style="margin-top: 24px; padding-top: 20px; border-top: 3px solid gainsboro; padding-left: 10px">
                <p style="font-size: 1rem; font-weight: bold; margin: 0 0 0px 0;">Data gambar dokumentasi</p>
                <p style="font-size: .9rem; margin: 6px 0 20px 0;">Data dokumentasi formulir</p>
            </div>

            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ol style="list-style: none">
                    <li style="margin-bottom: 8px"><u><?php echo e($image->label); ?> :</u></li>
                    <li class="value-input">
                        <span style="display: inline-block; font-weight: bold">File Gambar - </span>
                        <a style="display: inline-block" href="<?php echo e(route('app.image.download', ['id' => $image->id])); ?>">
                            <?php echo e($image->name); ?>

                        </a>
                    </li>
                </ol>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endif; ?>
    </div>
    <div style="text-align: center; margin-top: 30px">
        <img src="data:image/png;base64,<?php echo e($logoDev); ?>" style="display: inline-block" width="80px" alt="Logo Dev">
        <p style="margin: 10px 0; font-size: 1.1rem; font-weight: bold">Sidescript Indonesia</p>
        <p style="margin: 5px 0; font-size: .8rem">Startup Digital Creative</p>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\emon.core\resources\views/monitoring_pdf.blade.php ENDPATH**/ ?>